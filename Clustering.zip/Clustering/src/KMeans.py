import numpy as np

def get_random_centroids(X, k):

    '''
    Each centroid is a point in RGB space (color) in the image. 
    This function should uniformly pick `k` centroids from the dataset.
    Input: a single image of shape `(num_pixels, 3)` and `k`, the number of centroids. 
    Notice we are flattening the image to a two dimentional array.
    Output: Randomly chosen centroids of shape `(k,3)` as a numpy array. 
    '''
    
    centroids = []
    centroids = np.random.uniform(0, 255, size=(k,3))
    return np.asarray(centroids).astype(np.float) 



def lp_distance(X, centroids, p=2):

    '''
    Inputs: 
    A single image of shape (num_pixels, 3)
    The centroids (k, 3)
    The distance parameter p

    output: numpy array of shape `(k, num_pixels)` thats holds the distances of 
    all points in RGB space from all centroids
    '''
    distances = []
    k = len(centroids)
    currentValue = X[:,None,:] - centroids[None,:,:]
    currentValue = currentValue ** p
    currentValue = np.sum(np.abs(currentValue), axis=2)
    distances = (currentValue ** (1 / p)).T

    return distances

def kmeans(X, k, p ,max_iter=100):
    """
    Inputs:
    - X: a single image of shape (num_pixels, 3).
    - k: number of centroids.
    - p: the parameter governing the distance measure.
    - max_iter: the maximum number of iterations to perform.

    Outputs:
    - The calculated centroids as a numpy array.
    - The final assignment of all RGB points to the closest centroids as a numpy array.
    """
    classes = []
    centroids = get_random_centroids(X, k)
    tempCentroids = np.empty([k, 3])

    for _ in range(max_iter):
        distances = lp_distance(X, centroids, p)
        classes = np.argmin(distances, axis=0)
        for i in range(k):
            ci = X[classes == i]
            if len(ci) > 0:
                tempCentroids[i,:] = np.mean(ci, axis=0)
        if np.all(centroids == tempCentroids):
            break
        centroids = tempCentroids

    return centroids, classes

def kmeans_pp(X, k, p ,max_iter=100):
    """
    Inputs:
    - X: a single image of shape (num_pixels, 3).
    - k: number of centroids.
    - p: the parameter governing the distance measure.
    - max_iter: the maximum number of iterations to perform.

    Outputs:
    - The calculated centroids as a numpy array.
    - The final assignment of all RGB points to the closest centroids as a numpy array.
    """
    classes = None
    centroids = np.zeros((k,3))
    randomIdx = np.random.randint(0, X.shape[0])
    centroids[0,:] = X[randomIdx,:]
    XCopy = X.copy()
    XCopy = np.delete(XCopy, randomIdx, axis=0)
    for i in range(1,k):
        distances = lp_distance(XCopy, centroids, p)

        # the minimum distance to the nearest centroid, axis 0 or 1?
        minDistanceMatrix = distances.min(axis=0) ** 2

        totalDistance = minDistanceMatrix.sum()
        weightedDistanceMatrix = minDistanceMatrix / totalDistance

        randomIdx = np.random.choice(XCopy.shape[0], size=1, replace=False, p=weightedDistanceMatrix)
        centroids[i,:] = XCopy[randomIdx,:]
        XCopy = np.delete(X, randomIdx, axis=0)
        
    tempCentroids = np.empty([k, 3])
    for _ in range(max_iter):
        distances = lp_distance(X, centroids, p)
        classes = np.argmin(distances, axis=0)
        for i in range(k):
            ci = X[classes == i]
            if len(ci) > 0:
                tempCentroids[i,:] = np.mean(ci, axis=0)
        if np.all(centroids == tempCentroids):
            break
        centroids = tempCentroids

    return centroids, classes
